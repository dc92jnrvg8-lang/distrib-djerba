#!/bin/bash
# DJERBA LINUX — Suite de tests v1.0
set -euo pipefail
VERBOSE="${DJERBA_TEST_VERBOSE:-0}"
[[ "${1:-}" == "--verbose" ]] && { VERBOSE=1; shift; }
FILTER="${1:-}"; PASS=0; FAIL=0; SKIP=0; FAILED=()

GRN='\033[0;32m';RED='\033[0;31m';YLW='\033[1;33m'
CYN='\033[0;36m';PUR='\033[0;35m';BLD='\033[1m';NC='\033[0m'

_pass() { ((PASS++)); echo -e "  ${GRN}✓${NC} $1"; }
_fail() { ((FAIL++)); FAILED+=("$1"); echo -e "  ${RED}✗${NC} $1: ${2:-}"; }
_skip() { ((SKIP++)); echo -e "  ${YLW}⊘${NC} $1 (skipped: ${2:-})"; }
_sec()  { echo -e "\n${PUR}${BLD}━━ $* ━━${NC}"; }
_run()  {
    local name="$1"; shift
    [[ -n "$FILTER" && "$name" != *"$FILTER"* ]] && return 0
    "$@" || true
}

# Tests syntaxe
test_bash_syntax() {
    _sec "Syntaxe Bash"
    for f in /usr/local/bin/djerba-anon.sh /usr/local/bin/djerba-gaming.sh \
              /usr/local/bin/djerba-hardening.sh /usr/local/bin/djerba-health.sh \
              /usr/local/bin/djerba-killswitch.sh /usr/local/bin/djerba-dns.sh \
              /usr/local/lib/djerba/djerba-lib.sh; do
        if [[ -f "$f" ]]; then
            bash -n "$f" && _pass "syntax_$(basename $f)" || _fail "syntax_$(basename $f)" "erreur syntaxe"
        else _skip "syntax_$(basename $f)" "absent"; fi
    done
}

test_python_syntax() {
    _sec "Syntaxe Python"
    for f in /usr/local/bin/djerba-installer.py /usr/local/bin/djerba-settings.py \
              /usr/local/bin/djerba-update-center.py /usr/local/bin/djerba-backup.py \
              /usr/local/bin/djerba-firewall.py /usr/local/bin/djerba-welcome.py \
              /usr/local/bin/djerba-vpn-widget.py /usr/local/bin/djerba-gaming-widget.py \
              /usr/local/bin/djerba-control-center.py /usr/local/lib/djerba/djerba_i18n.py; do
        if [[ -f "$f" ]]; then
            python3 -m py_compile "$f" && _pass "syntax_$(basename $f)" || _fail "syntax_$(basename $f)" "erreur syntaxe"
        else _skip "syntax_$(basename $f)" "absent"; fi
    done
}

test_commands() {
    _sec "Commandes disponibles"
    for cmd in djerba-anon djerba-gaming djerba-gaming-widget djerba-killswitch \
                djerba-health djerba-hardening djerba-dns djerba-backup \
                djerba-firewall djerba-update-center djerba-welcome \
                djerba-control-center djerba-vpn-widget djerba-settings \
                djerba-installer djerba-post-install djerba-wallpapers; do
        [[ -f "/usr/local/bin/$cmd" ]] && _pass "cmd_$cmd" || _fail "cmd_$cmd" "absent"
        [[ -x "/usr/local/bin/$cmd" ]] && _pass "exec_$cmd" || _fail "exec_$cmd" "non exécutable"
    done
}

test_desktop_entries() {
    _sec "Desktop entries"
    for e in djerba-control-center djerba-gaming-widget djerba-vpn-widget \
              djerba-update-center djerba-backup djerba-firewall djerba-health \
              djerba-welcome djerba-post-install djerba-settings djerba-gaming \
              djerba-dns djerba-anon; do
        local p="/usr/share/applications/${e}.desktop"
        if [[ -f "$p" ]]; then
            grep -q "^Name=" "$p" && _pass "desktop_name_$e" || _fail "desktop_name_$e" "Name manquant"
            grep -q "^Exec=" "$p" && _pass "desktop_exec_$e" || _fail "desktop_exec_$e" "Exec manquant"
        else _skip "desktop_$e" "absent"; fi
    done
}

test_i18n() {
    _sec "i18n FR/EN"
    local I="/usr/local/lib/djerba/djerba_i18n.py"
    [[ ! -f "$I" ]] && { _skip "i18n" "absent"; return; }
    out=$(python3 -c "
import sys; sys.path.insert(0,'/usr/local/lib/djerba')
from djerba_i18n import tr,set_lang
set_lang('fr'); print(tr('btn.apply'))
")
    [[ "$out" == "Appliquer" ]] && _pass "i18n_fr" || _fail "i18n_fr" "attendu Appliquer, got $out"
    out=$(python3 -c "
import sys; sys.path.insert(0,'/usr/local/lib/djerba')
from djerba_i18n import tr,set_lang
set_lang('en'); print(tr('btn.apply'))
")
    [[ "$out" == "Apply" ]] && _pass "i18n_en" || _fail "i18n_en" "attendu Apply, got $out"
    out=$(python3 -c "
import sys; sys.path.insert(0,'/usr/local/lib/djerba')
from djerba_i18n import tr,set_lang
set_lang('fr'); print(tr('themes.applying', theme='macOS'))
")
    [[ "$out" == *"macOS"* ]] && _pass "i18n_interpolation" || _fail "i18n_interpolation" "interpolation échouée"
}

test_packages() {
    _sec "packages.x86_64"
    local PKG
    PKG="$(dirname "$0")/../packages.x86_64"
    [[ ! -f "$PKG" ]] && { _skip "packages" "absent"; return; }
    for p in base linux-zen grub plasma-meta nvidia-dkms apparmor tor virt-manager python; do
        grep -q "^$p$" "$PKG" && _pass "pkg_$p" || _fail "pkg_$p" "$p absent"
    done
    ! grep -q "^docker$" "$PKG" && _pass "pkg_no_docker" || _fail "pkg_no_docker" "docker ne devrait pas être là"
}

test_themes() {
    _sec "Thèmes & visuels"
    [[ -f "/usr/share/plymouth/themes/djerba/djerba.plymouth" ]] && \
        _pass "plymouth_descriptor" || _skip "plymouth_descriptor" "absent"
    [[ -f "/usr/share/sddm/themes/djerba/Main.qml" ]] && \
        _pass "sddm_main" || _skip "sddm_main" "absent"
    [[ -f "/boot/grub/themes/djerba/theme.txt" ]] && \
        _pass "grub_theme" || _skip "grub_theme" "absent"
}

test_no_kader() {
    _sec "Vérification renommage Kader → Djerba"
    local remaining
    remaining=$(grep -ri "kader" /usr/local/bin/ /usr/local/lib/ \
        /usr/share/applications/ 2>/dev/null | grep -v ".pyc" | wc -l || echo 0)
    if [[ "$remaining" -eq 0 ]]; then
        _pass "no_kader_references"
    else
        _fail "no_kader_references" "$remaining référence(s) kader encore présentes"
    fi
}

echo ""
echo -e "${BLD}╔═══════════════════════════════════════╗${NC}"
echo -e "${BLD}║  Djerba Linux — Test Suite           ║${NC}"
echo -e "${BLD}╚═══════════════════════════════════════╝${NC}"

_run "bash"     test_bash_syntax
_run "python"   test_python_syntax
_run "commands" test_commands
_run "desktop"  test_desktop_entries
_run "i18n"     test_i18n
_run "packages" test_packages
_run "themes"   test_themes
_run "rename"   test_no_kader

echo ""
echo -e "${BLD}━━ Résultats ━━${NC}"
echo -e "  ${GRN}Succès : $PASS${NC}  ${YLW}Ignorés : $SKIP${NC}  ${RED}Échecs : $FAIL${NC}"
[[ ${#FAILED[@]} -gt 0 ]] && { echo ""; echo -e "  ${RED}Tests échoués :${NC}"; for t in "${FAILED[@]}"; do echo -e "    ✗ $t"; done; }
echo ""
[[ $FAIL -eq 0 ]] && echo -e "  ${GRN}${BLD}✅ Tous les tests passent !${NC}" && exit 0
echo -e "  ${RED}${BLD}❌ $FAIL test(s) en échec${NC}" && exit 1
