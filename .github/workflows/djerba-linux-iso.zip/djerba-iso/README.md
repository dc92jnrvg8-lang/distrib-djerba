# 🏖️ Djerba Linux

Distribution Arch Linux personnalisée — Dell G15 · RTX 3060 · 32 Go RAM

---

## Présentation

| Composant | Détail |
|---|---|
| **Kernel** | linux-zen + linux-lts (fallback) |
| **Bureau** | KDE Plasma 6 — Wayland |
| **Thèmes** | macOS · Windows 11 · GNOME · Catppuccin · Gruvbox · Nord |
| **GPU** | NVIDIA RTX 3060 + Intel Optimus |
| **Sécurité** | LUKS2 · AppArmor · nftables · Firejail · Secure Boot |
| **Anonymat** | Tor · VPN Kill Switch · MAC spoof · DNS DoH |
| **Gaming** | GameMode · MangoHud · prime-run |
| **Virtualisation** | virt-manager · QEMU/KVM |
| **Langue** | Français (AZERTY) |

---

## Build de l'ISO

### ⚠️ iPhone / iPad : IMPOSSIBLE
iOS ne peut pas exécuter de scripts bash, Docker, ou mkarchiso.
Il faut obligatoirement un ordinateur Linux ou macOS.

### Option A — Dell G15 sous Ubuntu (recommandé)
```bash
bash build-ubuntu.sh
# Docker installé automatiquement si absent
# ISO dans output/ après 30-60 min
```

### Option B — GitHub Actions (gratuit, dans le cloud)
1. Créer un repo GitHub
2. Pusher ce dossier
3. Actions → Build ISO → artifact téléchargeable

### Option C — Arch Linux natif
```bash
sudo bash build-iso.sh
```

### Tester en VM (virt-manager)
```
RAM : 4 Go · CPU : 2 cœurs · Disque : 40 Go · Boot : ISO
```

---

## Installation

**Flux :** Boot USB → GRUB → Live KDE → Installeur automatique

**Wizard :** Bienvenue → Disque → Utilisateur → LUKS2 → Thème → Apps → Install → Terminé

**Dual Boot Windows :** os-prober activé, détection automatique.

**Secure Boot :** sbctl + clés Microsoft. Désactiver dans BIOS pendant l'install.

---

## Commandes djerba-*

```bash
djerba-control-center    # Hub central
djerba-anon start/stop   # Mode anonyme Tor
djerba-killswitch enable # Kill switch VPN
djerba-gaming start/stop # Optimisations gaming
djerba-gaming-widget     # Boutons bureau Gaming ON/OFF
djerba-vpn-widget        # Boutons bureau VPN ON/OFF
djerba-health            # Rapport santé système
djerba-hardening apply   # Hardening sécurité
djerba-dns setup/test    # DNS over HTTPS
djerba-update-center     # Mises à jour
djerba-backup            # GUI Restic
djerba-firewall          # GUI nftables
djerba-settings          # Panneau thèmes KDE
djerba-post-install      # Wizard Git + SSH + Tailscale
```

---

## Thèmes

```bash
djerba-theme-switcher macos|windows11|gnome|catppuccin|gruvbox|nord
```

GUI : **Paramètres Système → Djerba Thèmes**

---

## Kill switch VPN

| Situation | Résultat |
|---|---|
| VPN crash accidentel | Tout bloqué + notif KDE urgente |
| Bouton **VPN OFF** | Trafic normal restauré automatiquement |

```bash
sudo djerba-killswitch disconnect  # avant de couper le VPN manuellement
```

---

## Gaming

**Gaming ON active :** CPU perf · NVIDIA max · Swappiness 0 · THP always · IO deadline

**Profils MangoHud :** competitive (FPS only) · benchmark (CSV) · streaming (OBS)

```bash
game mon_jeu                          # alias : gamemoderun prime-run mangohud
djerba-gaming profile benchmark       # changer profil
```

---

## Tests

```bash
bash tests/test-all.sh              # tous les tests
bash tests/test-all.sh bash         # syntaxe bash uniquement
bash tests/test-all.sh --verbose    # mode verbeux
```

---

## Développement

### Bibliothèque partagée
```bash
source /usr/local/lib/djerba/djerba-lib.sh
log "OK"
djerba_notify_ok "Titre" "Message"
djerba_set_state "clé" "valeur"
```

### i18n Python
```python
import sys; sys.path.insert(0, '/usr/local/lib/djerba')
from djerba_i18n import tr, set_lang
tr("btn.apply")                      # "Appliquer" ou "Apply"
tr("themes.applying", theme="macOS") # interpolation
```
