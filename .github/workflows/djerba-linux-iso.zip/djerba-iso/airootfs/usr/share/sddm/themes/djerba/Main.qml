import QtQuick 2.15
import QtQuick.Controls 2.15
import SddmComponents 2.0
Rectangle {
    id: root; width: 1920; height: 1080; color: "#11111B"
    Rectangle {
        anchors.fill: parent
        gradient: Gradient {
            GradientStop { position: 0.0; color: "#11111B" }
            GradientStop { position: 1.0; color: "#1E1E2E" }
        }
    }
    Column {
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.top: parent.top; anchors.topMargin: 160; spacing: 8
        Text {
            text: "DJERBA"; font.family: "Inter"; font.pixelSize: 72
            font.bold: true; color: "#CBA6F7"
            anchors.horizontalCenter: parent.horizontalCenter
        }
        Text {
            text: "LINUX"; font.family: "Inter"; font.pixelSize: 22
            font.letterSpacing: 8; color: "#585B70"
            anchors.horizontalCenter: parent.horizontalCenter
        }
    }
    Rectangle {
        width: 400; height: 200; anchors.centerIn: parent
        anchors.verticalCenterOffset: 20; color: "transparent"
        Column { anchors.fill: parent; spacing: 14
            Rectangle {
                width: parent.width; height: 46; color: "#1E1E2E"; radius: 12
                border.color: userField.activeFocus ? "#CBA6F7" : "#313244"
                TextInput {
                    id: userField; anchors { fill: parent; margins: 14 }
                    font.family: "Inter"; font.pixelSize: 15; color: "#CDD6F4"
                    text: userModel.lastUser || ""
                    verticalAlignment: TextInput.AlignVCenter
                    KeyNavigation.tab: passwordField
                    Text { anchors.fill: parent; text: "Utilisateur"
                        font: parent.font; color: "#45475A"
                        verticalAlignment: Text.AlignVCenter
                        visible: parent.text.length === 0 }
                }
            }
            Rectangle {
                width: parent.width; height: 46; color: "#1E1E2E"; radius: 12
                border.color: passwordField.activeFocus ? "#CBA6F7" : "#313244"
                TextInput {
                    id: passwordField; anchors { fill: parent; margins: 14 }
                    font.family: "Inter"; font.pixelSize: 15; color: "#CDD6F4"
                    echoMode: TextInput.Password
                    verticalAlignment: TextInput.AlignVCenter
                    Text { anchors.fill: parent; text: "Mot de passe"
                        font: parent.font; color: "#45475A"
                        verticalAlignment: Text.AlignVCenter
                        visible: parent.text.length === 0 }
                    Keys.onReturnPressed: sddm.login(userField.text, passwordField.text, sessionIndex)
                }
            }
            Rectangle {
                width: parent.width; height: 46; radius: 12; color: "#CBA6F7"
                Text { anchors.centerIn: parent; text: "Se connecter"
                    color: "#1E1E2E"; font.family: "Inter"
                    font.pixelSize: 15; font.bold: true }
                MouseArea { anchors.fill: parent
                    onClicked: sddm.login(userField.text, passwordField.text, sessionIndex) }
            }
        }
    }
    Text {
        anchors.bottom: parent.bottom; anchors.bottomMargin: 40
        anchors.right: parent.right; anchors.rightMargin: 40
        font.family: "Inter"; font.pixelSize: 38; font.bold: true; color: "#CDD6F4"
        id: clockLabel
    }
    Timer { interval: 1000; repeat: true; running: true
        onTriggered: clockLabel.text = Qt.formatTime(new Date(), "hh:mm")
        Component.onCompleted: triggered() }
    Connections { target: sddm
        function onLoginFailed() {
            passwordField.text = ""; passwordField.forceActiveFocus() } }
    Component.onCompleted: passwordField.forceActiveFocus()
}
