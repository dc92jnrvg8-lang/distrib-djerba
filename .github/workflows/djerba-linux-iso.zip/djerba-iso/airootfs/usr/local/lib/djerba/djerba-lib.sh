#!/bin/bash
# DJERBA-LIB — Bibliothèque partagée v1.0
# Usage : source /usr/local/lib/djerba/djerba-lib.sh
[[ -n "${_DJERBA_LIB_LOADED:-}" ]] && return 0
readonly _DJERBA_LIB_LOADED=1

if [[ -t 1 ]]; then
    GRN='\033[0;32m';YLW='\033[1;33m';CYN='\033[0;36m'
    RED='\033[0;31m';PUR='\033[0;35m';BLD='\033[1m';NC='\033[0m'
else GRN='';YLW='';CYN='';RED='';PUR='';BLD='';NC=''; fi

readonly DJERBA_LOG_FILE="${DJERBA_LOG_FILE:-/var/log/djerba.log}"
readonly DJERBA_SCRIPT_NAME="${DJERBA_SCRIPT_NAME:-$(basename "$0" .sh)}"
_dlog() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] [$1] [$DJERBA_SCRIPT_NAME] ${*:2}" >> "$DJERBA_LOG_FILE" 2>/dev/null||true; }

log()     { echo -e "${GRN}[✓]${NC} $*"; _dlog INFO "$*"; }
warn()    { echo -e "${YLW}[⚠]${NC} $*"; _dlog WARN "$*"; }
error()   { echo -e "${RED}[✗]${NC} $*" >&2; _dlog ERROR "$*"; exit 1; }
info()    { echo -e "${CYN}[→]${NC} $*"; _dlog DEBUG "$*"; }
section() { echo -e "\n${PUR}${BLD}━━ $* ━━${NC}\n"; _dlog INFO "=== $* ==="; }

djerba_require_root() { [[ $EUID -eq 0 ]] || error "Root requis : sudo $0 $*"; }
djerba_check_internet() { ping -c1 -W3 archlinux.org &>/dev/null; }
djerba_get_net_iface() { ip route show default 2>/dev/null | awk '/default/ {print $5; exit}'; }
djerba_get_vpn_iface() {
    for i in tun0 tun1 wg0 wg1 proton0 nordlynx; do
        ip link show "$i" &>/dev/null && { echo "$i"; return 0; }; done; return 1; }
djerba_get_gui_uid() {
    local u="${SUDO_UID:-}"
    [[ -n "$u" ]] && { echo "$u"; return; }
    who | grep -E ":[0-9]" | head -1 | awk '{print $1}' | xargs id -u 2>/dev/null || echo 1000; }

djerba_notify() {
    local title="$1" body="${2:-}" icon="${3:-djerba}" urgency="${4:-normal}"
    local uid; uid=$(djerba_get_gui_uid)
    DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/$uid/bus" DISPLAY=:0 \
    sudo -u "#$uid" notify-send --app-name="Djerba" --icon="$icon" \
        --urgency="$urgency" "$title" "$body" 2>/dev/null||true; }

djerba_notify_ok()       { djerba_notify "$1" "${2:-}" "dialog-information" "low"; }
djerba_notify_warn()     { djerba_notify "$1" "${2:-}" "dialog-warning" "normal"; }
djerba_notify_error()    { djerba_notify "$1" "${2:-}" "dialog-error" "critical"; }
djerba_notify_gaming()   { djerba_notify "$1" "${2:-}" "applications-games" "normal"; }
djerba_notify_vpn()      { djerba_notify "$1" "${2:-}" "network-vpn" "normal"; }
djerba_notify_security() { djerba_notify "$1" "${2:-}" "security-high" "normal"; }
djerba_notify_update()   { djerba_notify "$1" "${2:-}" "system-software-update" "low"; }

readonly DJERBA_STATE_DIR="/tmp/djerba"; mkdir -p "$DJERBA_STATE_DIR" 2>/dev/null||true
djerba_set_state()   { echo "$2" > "$DJERBA_STATE_DIR/$1"; }
djerba_get_state()   { cat "$DJERBA_STATE_DIR/$1" 2>/dev/null || echo "${2:-}"; }
djerba_clear_state() { rm -f "$DJERBA_STATE_DIR/$1"; }
djerba_has_state()   { [[ -f "$DJERBA_STATE_DIR/$1" ]]; }

djerba_confirm() {
    echo -ne "${YLW}[?]${NC} ${1:-Confirmer ?} [oui/non] : "
    read -r a; [[ "${a,,}" == "oui" ]]; }

djerba_human_duration() {
    local s="$1" h=$((s/3600)) m=$(((s%3600)/60)) sec=$((s%60))
    [[ $h -gt 0 ]] && echo -n "${h}h "; [[ $m -gt 0 ]] && echo -n "${m}m "; echo "${sec}s"; }

export -f log warn error info section djerba_notify djerba_notify_ok
export -f djerba_notify_warn djerba_notify_error djerba_notify_gaming djerba_notify_vpn
export -f djerba_set_state djerba_get_state djerba_clear_state djerba_has_state
