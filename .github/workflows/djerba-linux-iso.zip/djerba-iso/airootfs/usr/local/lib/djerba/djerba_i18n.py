"""DJERBA-I18N — Internationalisation FR/EN v1.0"""
import os, locale
_LANG = "fr"

def set_lang(lang):
    global _LANG
    if lang in TRANSLATIONS: _LANG = lang

def detect_lang():
    k = os.environ.get("DJERBA_LANG","").lower()
    if k.startswith("en"): return "en"
    s = locale.getdefaultlocale()[0] or ""
    return "en" if s.startswith("en") else "fr"

def tr(key, **kw):
    text = TRANSLATIONS.get(_LANG,{}).get(key) or \
           TRANSLATIONS.get("fr",{}).get(key) or key
    if kw:
        try: text = text.format(**kw)
        except: pass
    return text

TRANSLATIONS = {
"fr": {
    "app.name":"Djerba Linux", "btn.apply":"Appliquer",
    "btn.cancel":"Annuler", "btn.close":"Fermer",
    "btn.next":"Suivant →", "btn.back":"← Retour",
    "btn.finish":"Terminer", "btn.save":"Enregistrer",
    "btn.install":"Installer", "btn.open":"Ouvrir →",
    "status.active":"Actif ✓", "status.inactive":"Inactif",
    "install.title":"Djerba Linux — Installation",
    "install.welcome.title":"Bienvenue dans Djerba Linux",
    "install.welcome.sub":"Arch Linux · KDE Plasma 6 · Polyvalent & Sécurisé",
    "install.disk.title":"Disque d'installation",
    "install.disk.warning":"⚠️  Le disque sélectionné sera entièrement effacé",
    "install.user.title":"Compte utilisateur",
    "install.user.err_mismatch":"❌ Les mots de passe ne correspondent pas",
    "install.user.err_short":"❌ Mot de passe trop court (6 caractères minimum)",
    "install.luks.enable":"Chiffrer le disque (recommandé)",
    "install.theme.title":"Choisir votre thème",
    "install.theme.sub":"Modifiable à tout moment dans les Paramètres Système",
    "install.done.title":"Installation terminée !",
    "install.done.reboot":"🔄  Redémarrer maintenant",
    "themes.title":"Djerba Thèmes",
    "themes.applying":"Application de {theme}...",
    "themes.success":"Thème {theme} appliqué avec succès !",
    "vpn.on":"▶  VPN ON", "vpn.off":"■  VPN OFF",
    "vpn.connected":"VPN Connecté — {iface}",
    "vpn.crashed":"VPN Perdu — Connexion BLOQUÉE !",
    "gaming.on":"▶  Gaming ON", "gaming.off":"■  Gaming OFF",
    "gaming.active":"Mode Gaming ACTIF",
    "gaming.notify_on":"🎮 Mode Gaming activé",
    "update.title":"Centre de mises à jour",
    "update.uptodate":"✓ Système à jour",
    "cc.title":"Djerba Control Center",
},
"en": {
    "app.name":"Djerba Linux", "btn.apply":"Apply",
    "btn.cancel":"Cancel", "btn.close":"Close",
    "btn.next":"Next →", "btn.back":"← Back",
    "btn.finish":"Finish", "btn.save":"Save",
    "btn.install":"Install", "btn.open":"Open →",
    "status.active":"Active ✓", "status.inactive":"Inactive",
    "install.title":"Djerba Linux — Installer",
    "install.welcome.title":"Welcome to Djerba Linux",
    "install.welcome.sub":"Arch Linux · KDE Plasma 6 · Versatile & Secure",
    "install.disk.title":"Installation Disk",
    "install.disk.warning":"⚠️  The selected disk will be completely erased",
    "install.user.title":"User Account",
    "install.user.err_mismatch":"❌ Passwords do not match",
    "install.user.err_short":"❌ Password too short (minimum 6 characters)",
    "install.luks.enable":"Encrypt disk (recommended)",
    "install.theme.title":"Choose your theme",
    "install.theme.sub":"Can be changed anytime in System Settings",
    "install.done.title":"Installation complete!",
    "install.done.reboot":"🔄  Reboot now",
    "themes.title":"Djerba Themes",
    "themes.applying":"Applying {theme}...",
    "themes.success":"Theme {theme} applied successfully!",
    "vpn.on":"▶  VPN ON", "vpn.off":"■  VPN OFF",
    "vpn.connected":"VPN Connected — {iface}",
    "vpn.crashed":"VPN Lost — Connection BLOCKED!",
    "gaming.on":"▶  Gaming ON", "gaming.off":"■  Gaming OFF",
    "gaming.active":"Gaming Mode ACTIVE",
    "gaming.notify_on":"🎮 Gaming Mode enabled",
    "update.title":"Update Center",
    "update.uptodate":"✓ System up to date",
    "cc.title":"Djerba Control Center",
},
}
set_lang(detect_lang())
