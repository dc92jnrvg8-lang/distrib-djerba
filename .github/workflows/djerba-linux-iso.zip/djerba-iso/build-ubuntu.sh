#!/bin/bash
# DJERBA LINUX — build depuis Ubuntu via Docker
set -e

GRN='\033[0;32m'; YLW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
log()   { echo -e "${GRN}[✓]${NC} $1"; }
warn()  { echo -e "${YLW}[⚠]${NC} $1"; }
error() { echo -e "${RED}[✗]${NC} $1"; exit 1; }

echo -e "\n\033[1;36m━━ Djerba Linux — Build via Docker ━━\033[0m\n"

if ! command -v docker &>/dev/null; then
    warn "Docker non trouvé — installation..."
    sudo apt-get update -qq
    sudo apt-get install -y ca-certificates curl gnupg
    sudo install -m 0755 -d /etc/apt/keyrings
    curl -fsSL https://download.docker.com/linux/ubuntu/gpg | \
        sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
    echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] \
https://download.docker.com/linux/ubuntu $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | \
        sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
    sudo apt-get update -qq
    sudo apt-get install -y docker-ce docker-ce-cli containerd.io
    sudo usermod -aG docker "$USER"
    warn "Docker installé — relancer : newgrp docker && bash build-ubuntu.sh"
    exit 0
fi

docker info &>/dev/null || error "Docker non accessible — essaie : newgrp docker && bash build-ubuntu.sh"
log "Docker OK ✓"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ISO_DIR="$SCRIPT_DIR/djerba-iso"
[[ ! -f "$ISO_DIR/profiledef.sh" ]] && error "djerba-iso/ non trouvé à côté de ce script"
OUTPUT_DIR="$SCRIPT_DIR/output"
mkdir -p "$OUTPUT_DIR"
log "Projet : $ISO_DIR → $OUTPUT_DIR"

log "Pull image Arch Linux..."
docker pull archlinux:latest

log "Build en cours (30-60 min)..."
docker run --rm --privileged --name djerba-build \
    -v "$ISO_DIR:/djerba-iso:ro" \
    -v "$OUTPUT_DIR:/output" \
    -v /dev:/dev \
    archlinux:latest bash -c '
set -e
pacman -Sy --noconfirm 2>/dev/null
pacman -S --noconfirm --needed archiso squashfs-tools libisoburn \
    syslinux grub efibootmgr dosfstools mtools reflector git python 2>/dev/null
reflector --country France,Germany --age 12 --protocol https \
    --sort rate --save /etc/pacman.d/mirrorlist 2>/dev/null || true
cp -r /djerba-iso /build
cd /build
echo "djerba-live" > airootfs/etc/hostname
echo "LANG=fr_FR.UTF-8" > airootfs/etc/locale.conf
echo "KEYMAP=fr" > airootfs/etc/vconsole.conf
mkdir -p airootfs/etc/systemd/system/multi-user.target.wants
for svc in sddm NetworkManager; do
    ln -sf "/usr/lib/systemd/system/$svc.service" \
        "airootfs/etc/systemd/system/multi-user.target.wants/$svc.service" 2>/dev/null || true
done
chmod +x airootfs/usr/local/bin/* 2>/dev/null || true
mkarchiso -v -w /tmp/djerba-work -o /output .
ls -lh /output/*.iso 2>/dev/null || echo "Aucune ISO trouvée"
'

ISO=$(ls "$OUTPUT_DIR"/*.iso 2>/dev/null | head -1)
[[ -f "$ISO" ]] || error "ISO non trouvée — vérifier les logs"
SIZE=$(du -sh "$ISO" | cut -f1)
sha256sum "$ISO" > "$OUTPUT_DIR/djerba-linux.sha256"

echo ""
echo -e "${GRN}\033[1m╔══════════════════════════════════════════╗\033[0m"
echo -e "${GRN}\033[1m║  ✅  ISO Djerba Linux générée !          ║\033[0m"
echo -e "${GRN}\033[1m╚══════════════════════════════════════════╝${NC}"
echo ""
echo -e "  \033[0;36mFichier :\033[0m $ISO"
echo -e "  \033[0;36mTaille  :\033[0m $SIZE"
echo ""
echo -e "  \033[1;33mTester en VM (virt-manager) :\033[0m"
echo -e "  RAM : 4 Go · CPU : 2 cœurs · Disque : 40 Go"
echo ""
echo -e "  \033[1;33mFlasher sur USB :\033[0m"
echo -e "  sudo dd if=\"$ISO\" of=/dev/sdX bs=4M status=progress oflag=sync"
echo ""
