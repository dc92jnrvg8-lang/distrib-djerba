#!/bin/bash
# DJERBA LINUX — build-iso.sh
# Build depuis une machine Arch Linux native
set -e
[[ $EUID -ne 0 ]] && echo "sudo requis" && exit 1
[[ ! -f profiledef.sh ]] && echo "Lance depuis djerba-iso/" && exit 1

OUTDIR="$(pwd)/output"; WORKDIR="/tmp/djerba-build/work"
mkdir -p "$OUTDIR" "$WORKDIR"

echo "━━ Installation dépendances ━━"
pacman -S --noconfirm --needed archiso squashfs-tools libisoburn \
    syslinux grub efibootmgr dosfstools mtools python reflector

echo "━━ Optimisation miroirs ━━"
reflector --country France,Germany --age 12 --protocol https \
    --sort rate --save /etc/pacman.d/mirrorlist 2>/dev/null || true
mkdir -p airootfs/etc/pacman.d
cp /etc/pacman.d/mirrorlist airootfs/etc/pacman.d/mirrorlist 2>/dev/null || true

echo "━━ Copie scripts Python ━━"
AIROOT="airootfs/usr/local/bin"
for f in djerba-installer djerba-settings djerba-update-center djerba-backup \
          djerba-firewall djerba-welcome djerba-vpn-widget djerba-gaming-widget \
          djerba-control-center djerba-post-install djerba-wallpapers; do
    [[ -f "../${f}.py" ]] && cp "../${f}.py" "$AIROOT/${f}.py" && \
        chmod +x "$AIROOT/${f}.py" && echo "  ✓ ${f}.py"
done
for f in djerba-anon djerba-gaming djerba-killswitch djerba-hardening \
          djerba-health djerba-dns; do
    [[ -f "../${f}.sh" ]] && cp "../${f}.sh" "$AIROOT/${f}.sh"
done
chmod +x "$AIROOT/"* 2>/dev/null || true

# Config locale live
echo "djerba-live" > airootfs/etc/hostname
echo "LANG=fr_FR.UTF-8" > airootfs/etc/locale.conf
echo "KEYMAP=fr" > airootfs/etc/vconsole.conf
mkdir -p airootfs/etc/systemd/system/multi-user.target.wants
for svc in sddm NetworkManager; do
    ln -sf "/usr/lib/systemd/system/$svc.service" \
        "airootfs/etc/systemd/system/multi-user.target.wants/$svc.service" 2>/dev/null || true
done

echo "━━ Build mkarchiso ━━"
mkarchiso -v -w "$WORKDIR" -o "$OUTDIR" "$(pwd)"

ISO=$(ls "$OUTDIR"/*.iso 2>/dev/null | head -1)
[[ -f "$ISO" ]] || { echo "❌ ISO non générée"; exit 1; }
SIZE=$(du -sh "$ISO" | cut -f1)
sha256sum "$ISO" > "$OUTDIR/djerba-linux.sha256"

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║  ✅  ISO Djerba Linux générée !          ║"
echo "╚══════════════════════════════════════════╝"
echo "  Fichier : $ISO"
echo "  Taille  : $SIZE"
echo "  Flash USB :"
echo "  sudo dd if=$ISO of=/dev/sdX bs=4M status=progress oflag=sync"
echo ""
read -rp "Nettoyer /tmp/djerba-build ? [o/N] " C
[[ "$C" =~ ^[oO]$ ]] && rm -rf /tmp/djerba-build && echo "Nettoyé ✓"
