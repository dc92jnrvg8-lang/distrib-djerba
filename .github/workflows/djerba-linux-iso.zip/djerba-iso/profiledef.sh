#!/usr/bin/env bash
iso_name="djerba-linux"
iso_label="DJERBA_$(date +%Y%m)"
iso_publisher="Djerba Linux"
iso_application="Djerba Linux — Live Installer"
iso_version="1.0"
install_dir="arch"
buildmodes=('iso')
bootmodes=(
    'bios.syslinux.mbr'
    'bios.syslinux.eltorito'
    'uefi-ia32.grub.esp'
    'uefi-x64.grub.esp'
)
arch="x86_64"
pacman_conf="pacman.conf"
airootfs_image_type="squashfs"
airootfs_image_tool_options=('-comp' 'xz' '-Xbcj' 'x86' '-b' '1M' '-Xdict-size' '1M')
file_permissions=(
    ["/etc/shadow"]="0:0:400"
    ["/etc/gshadow"]="0:0:400"
    ["/usr/local/bin/install-djerba.sh"]="0:0:755"
    ["/usr/local/bin/djerba-anon.sh"]="0:0:755"
    ["/usr/local/bin/djerba-gaming.sh"]="0:0:755"
    ["/usr/local/bin/djerba-killswitch.sh"]="0:0:755"
    ["/usr/local/bin/djerba-hardening.sh"]="0:0:755"
    ["/usr/local/bin/djerba-health.sh"]="0:0:755"
    ["/usr/local/bin/djerba-dns.sh"]="0:0:755"
    ["/usr/local/lib/djerba/djerba-lib.sh"]="0:0:644"
    ["/root/.config/autostart/djerba-installer.desktop"]="0:0:644"
)
